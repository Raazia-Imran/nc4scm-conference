import { SpeedInsights } from "@vercel/speed-insights/react";
import { useEffect, useState } from "react";
import { Link, Route, Routes, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Building2,
  CalendarCheck,
  CalendarDays,
  Download,
  ExternalLink,
  Factory,
  FileText,
  FlaskConical,
  Handshake,
  Images,
  Leaf,
  Mail,
  MapPin,
  Maximize2,
  Menu,
  Recycle,
  Send,
  ShieldCheck,
  Users,
  X,
} from "lucide-react";
import { dates, nav, people, trackGroups } from "./data";

const img = (name: string) => `/images/${name}`;

function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const loc = useLocation();
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 38);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => {
    setOpen(false);
  }, [loc.pathname]);
  const headerNav = nav.filter(([, p]) => p !== "/" && p !== "/registration");
  return (
    <div className={`navigation-shell ${scrolled ? "is-scrolled" : ""}`}>
      <div className="topbar">
        <span>27–28 APRIL 2027 · LAHORE</span>
        <a href="mailto:nc4scm@cloud.neduet.edu.pk">
          <Mail size={14} /> nc4scm@cloud.neduet.edu.pk
        </a>
      </div>
      <header>
        <Link className="brand" to="/" aria-label="GCGC 2027 conference home">
          <span className="conference-mark">GCGC 2027</span>
        </Link>
        <button
          className="menu"
          onClick={() => setOpen(!open)}
          aria-expanded={open}
          aria-label="Open navigation"
        >
          {open ? <X /> : <Menu />}
        </button>
        <nav className={open ? "open" : ""}>
          {headerNav.map(([n, p]) => (
            <Link className={loc.pathname === p ? "active" : ""} key={p} to={p}>
              {p === "/call-for-papers" ? "Papers" : n}
            </Link>
          ))}
          <Link
            className={
              loc.pathname === "/registration" ? "nav-cta active" : "nav-cta"
            }
            to="/registration"
          >
            Register
          </Link>
        </nav>
      </header>
      {open && (
        <button
          className="nav-scrim"
          aria-label="Close menu"
          onClick={() => setOpen(false)}
        />
      )}
    </div>
  );
}

function Footer() {
  return (
    <footer>
      <div className="footer-brand">
        <h3>GCGC 2027</h3>
        <p>
          Global Conference on Green Construction Materials and Practices 2027.
        </p>
        <span>
          Powered by the{" "}
          <b>National Center for Sustainable Construction Materials (NC4SCM)</b>
        </span>
      </div>
      <div>
        <h4>Explore</h4>
        {nav.slice(1, 7).map(([n, p]) => (
          <Link key={p} to={p}>
            {n}
          </Link>
        ))}
      </div>
      <div>
        <h4>Resources</h4>
        <Link to="/call-for-papers">Submission guidelines</Link>
        <a href="/downloads/GCGC_Paper_Template.docm" download>
          Paper template
        </a>
        <a
          href="/downloads/Springer_Nature_Proceedings_Guidelines.pdf"
          download
        >
          Proceedings guidelines
        </a>
        <Link to="/archive">2025 archive</Link>
      </div>
      <div>
        <h4>Contact</h4>
        <p>
          Lahore, Pakistan
          <br />
          27–28 April 2027
        </p>
        <a href="mailto:nc4scm@cloud.neduet.edu.pk">
          nc4scm@cloud.neduet.edu.pk
        </a>
      </div>
      <div className="copyright">© 2027 GCGC. Powered by NC4SCM.</div>
    </footer>
  );
}

const Reveal = ({
  children,
  className = "",
}: {
  children: any;
  className?: string;
}) => (
  <motion.div
    className={className}
    initial={{ opacity: 0, y: 28 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.15 }}
    transition={{ duration: 0.65 }}
  >
    {children}
  </motion.div>
);
function PageHero({
  eyebrow,
  title,
  copy,
}: {
  eyebrow: string;
  title: string;
  copy: string;
}) {
  return (
    <section className="page-hero">
      <div className="grain" />
      <Reveal>
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        <p>{copy}</p>
      </Reveal>
    </section>
  );
}
function Button({
  to,
  children,
  ghost = false,
}: {
  to: string;
  children: any;
  ghost?: boolean;
}) {
  return to.startsWith("http") ? (
    <a
      className={ghost ? "button ghost" : "button"}
      href={to}
      target="_blank"
      rel="noreferrer"
    >
      {children}
      <ArrowRight size={17} />
    </a>
  ) : (
    <Link className={ghost ? "button ghost" : "button"} to={to}>
      {children}
      <ArrowRight size={17} />
    </Link>
  );
}
function Countdown() {
  const target = new Date("2027-04-27T09:00:00+05:00").getTime();
  const [left, setLeft] = useState(() => Math.max(0, target - Date.now()));
  useEffect(() => {
    const timer = window.setInterval(
      () => setLeft(Math.max(0, target - Date.now())),
      1000,
    );
    return () => window.clearInterval(timer);
  }, []);
  const total = Math.floor(left / 1000);
  const values = [
    Math.floor(total / 86400),
    Math.floor((total % 86400) / 3600),
    Math.floor((total % 3600) / 60),
    total % 60,
  ];
  return (
    <div className="countdown" aria-label="Countdown to 27 April 2027">
      {values.map((value, index) => (
        <div key={index}>
          <b>{String(value).padStart(2, "0")}</b>
          <span>{["Days", "Hours", "Minutes", "Seconds"][index]}</span>
        </div>
      ))}
    </div>
  );
}

function SubmissionDownloads({ compact = false }: { compact?: boolean }) {
  const files = [
    {
      title: "GCGC paper template",
      copy: "Editable Springer manuscript template for preparing your submission",
      href: "/downloads/GCGC_Paper_Template.docm",
      meta: "DOCM",
      Icon: FileText,
    },
    {
      title: "Proceedings guidelines",
      copy: "Springer Nature guidance for conference proceedings preparation",
      href: "/downloads/Springer_Nature_Proceedings_Guidelines.pdf",
      meta: "PDF",
      Icon: BookOpen,
    },
  ];
  return (
    <section
      className={
        compact
          ? "submission-downloads compact-downloads"
          : "submission-downloads section"
      }
    >
      <div className="downloads-heading">
        <span className="eyebrow dark">AUTHOR RESOURCES</span>
        <h2>Prepare your paper</h2>
        {!compact && (
          <p>
            Download the official files before formatting and submitting your
            manuscript
          </p>
        )}
      </div>
      <div className="download-cards">
        {files.map(({ title, copy, href, meta, Icon }) => (
          <a href={href} download className="download-card" key={href}>
            <Icon />
            <div>
              <small>{meta} · DOWNLOAD</small>
              <h3>{title}</h3>
              <p>{copy}</p>
            </div>
            <Download />
          </a>
        ))}
      </div>
    </section>
  );
}

type MediaItem = { src: string; alt: string; label: string };
function MediaLightbox({
  items,
  index,
  onIndex,
  onClose,
}: {
  items: MediaItem[];
  index: number;
  onIndex: (index: number) => void;
  onClose: () => void;
}) {
  const move = (step: number) =>
    onIndex((index + step + items.length) % items.length);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "ArrowRight") move(1);
      if (event.key === "ArrowLeft") move(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index]);
  return (
    <div
      className="media-lightbox"
      role="dialog"
      aria-modal="true"
      aria-label="Media viewer"
      onWheel={(event) => {
        if (Math.abs(event.deltaY) > 20) move(event.deltaY > 0 ? 1 : -1);
      }}
    >
      <button
        className="media-backdrop"
        onClick={onClose}
        aria-label="Close media viewer"
      />
      <div className="media-viewer">
        <button className="media-close" onClick={onClose} aria-label="Close">
          <X />
        </button>
        <img src={items[index].src} alt={items[index].alt} />
        <div className="media-caption">
          <span>
            {String(index + 1).padStart(2, "0")} /{" "}
            {String(items.length).padStart(2, "0")}
          </span>
          <p>{items[index].label}</p>
          <small>Use arrows or scroll to explore</small>
        </div>
        <button
          className="media-prev"
          onClick={() => move(-1)}
          aria-label="Previous image"
        >
          <ArrowLeft />
        </button>
        <button
          className="media-next"
          onClick={() => move(1)}
          aria-label="Next image"
        >
          <ArrowRight />
        </button>
      </div>
    </div>
  );
}

function Home() {
  const [selectedTrack, setSelectedTrack] = useState<number | null>(null);
  const [paused, setPaused] = useState(false);
  const loop = [...trackGroups, ...trackGroups];
  const homeMedia: MediaItem[] = [
    {
      src: img("gcgc-2025/event-01.webp"),
      alt: "Delegates seated in the auditorium during GCGC 2025",
      label: "The conference community · GCGC 2025",
    },
    {
      src: img("gcgc-2025/event-07.webp"),
      alt: "Wide view of the GCGC 2025 auditorium and delegates",
      label: "Ideas shared in the room · GCGC 2025",
    },
    {
      src: img("gcgc-2025/event-14.webp"),
      alt: "Guests inaugurating a conference activity at GCGC 2025",
      label: "A collaborative opening · GCGC 2025",
    },
    {
      src: img("gcgc-2025/event-17.webp"),
      alt: "GCGC 2025 participants gathered after the programme",
      label: "The next generation of practice · GCGC 2025",
    },
    {
      src: img("gcgc-2025/event-18.webp"),
      alt: "GCGC 2025 conference display and partner backdrop",
      label: "Green construction in focus · GCGC 2025",
    },
  ];
  return (
    <>
      <section className="hero conference-hero">
        <div className="hero-media">
          <img
            src={img("plant-aerial.jpg")}
            alt="Low-carbon cement production facility"
          />
          <div className="scan" />
        </div>
        <div className="hero-overlay" />
        <div className="hero-grid" />
        <div className="hero-copy">
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="eyebrow"
          >
            27–28 APRIL 2027 · LAHORE
          </motion.span>
          <motion.h1
            className="conference-name"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
          >
            GCGC <em>2027</em>
          </motion.h1>
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.25 }}
          >
            Global Conference on Green Construction
            <br />
            Materials and Practices
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.35 }}
          >
            Powered by the National Center for Sustainable Construction
            Materials (NC4SCM)
          </motion.p>
          <Countdown />
          <motion.div
            className="actions"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <Button to="/call-for-papers">Submission guidelines</Button>
            <Button to="/about" ghost>
              Explore conference
            </Button>
          </motion.div>
        </div>
        <div className="hero-side conference-focus">
          <span>Conference focus</span>
          <b>
            Materials innovation
            <br />
            Sustainable construction
            <br />
            Applied practice
          </b>
          <div>
            <MapPin size={17} /> Lahore, Pakistan
          </div>
        </div>
      </section>
      <section className="ticker" aria-label="Conference focus areas">
        <div className="ticker-loop">
          {[0, 1].map((group) => (
            <div className="ticker-group" key={group}>
              <span>
                <Factory /> LOW-CARBON CEMENT
              </span>
              <span>
                <Recycle /> CIRCULAR MATERIALS
              </span>
              <span>
                <Building2 /> SUSTAINABLE CONSTRUCTION
              </span>
              <span>
                <FlaskConical /> WHOLE-LIFE PERFORMANCE
              </span>
            </div>
          ))}
        </div>
      </section>
      <section
        className="institution-strip"
        aria-label="Conference institutions"
      >
        <div className="institution-heading">
          <span>Conference institutions</span>
          <h2>Organized and supported by</h2>
        </div>
        <div className="institution-logos">
          <div
            className="nc4scm-logo"
            aria-label="National Center for Sustainable Construction Materials"
          >
            <b>NC4SCM</b>
            <small>
              National Center for Sustainable
              <br />
              Construction Materials
            </small>
          </div>
          <div className="institution-logo">
            <img
              src={img("logos/ned.png")}
              alt="NED University of Engineering and Technology logo"
            />
            <span>NED University</span>
          </div>
          <div className="institution-logo">
            <img
              src={img("logos/iep.png")}
              alt="Institution of Engineers Pakistan logo"
            />
            <span>IEP</span>
          </div>
          <div className="institution-logo">
            <img
              src={img("logos/uet-lahore.png")}
              alt="University of Engineering and Technology Lahore logo"
            />
            <span>UET Lahore</span>
          </div>
          <div className="institution-logo">
            <img
              src={img("logos/lc3.png")}
              alt="LC3 Limestone Calcined Clay Cement logo"
            />
            <span>LC3</span>
          </div>
        </div>
      </section>
      <section className="intro section">
        <Reveal>
          <span className="eyebrow dark">WHY THIS CONFERENCE</span>
          <h2>
            Building green requires
            <br />a united ecosystem
          </h2>
        </Reveal>
        <Reveal>
          <p>
            Building materials contribute nearly 11% of global CO₂ emissions.
            GCGC brings industry, academia, and government together on one
            platform to share ideas, collaborate, and mitigate this impact.
          </p>
          <Button to="/about" ghost>
            Discover our purpose
          </Button>
        </Reveal>
      </section>
      <section className="tracks track-stage">
        <Reveal className="section-title section">
          <span className="eyebrow dark">03 TRACKS · 09 RESEARCH AREAS</span>
          <h2>Conference tracks</h2>
          <p>
            Three connected tracks bring materials, sustainable construction,
            policy and applied practice into one programme. Select a track to
            explore its research areas.
          </p>
        </Reveal>
        <div
          className={`track-rail ${paused ? "paused" : ""}`}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onPointerDown={() => setPaused(true)}
          onPointerUp={() => setPaused(false)}
        >
          {loop.map((group, i) => (
            <button
              className="track-card"
              key={`${group.number}-${i}`}
              onClick={() => setSelectedTrack(i % trackGroups.length)}
              aria-label={`Open track ${group.number}: ${group.title}`}
            >
              <span>TRACK / {group.number}</span>
              <h3>{group.title}</h3>
              <p>{group.topics.map((topic) => topic[1]).join(" · ")}</p>
              <i>
                <ArrowRight />
              </i>
            </button>
          ))}
        </div>
        <div className="rail-status section" aria-hidden="true">
          <span>PRIMARY TRACKS</span>
          <span className="rail-line" />
          <span>01—03</span>
        </div>
      </section>
      <section className="metrics">
        <div>
          <b>03</b>
          <span>Primary tracks</span>
        </div>
        <div>
          <b>09</b>
          <span>Research areas</span>
        </div>
        <div>
          <b>27–28</b>
          <span>April 2027</span>
        </div>
        <div>
          <b>Lahore</b>
          <span>Conference city</span>
        </div>
      </section>
      <SubmissionDownloads compact />
      <section className="dates section">
        <Reveal>
          <span className="eyebrow">PROPOSED SUBMISSION TIMELINE</span>
          <h2>Important dates</h2>
          <p>
            Eight milestones guide authors from the call for papers to GCGC 2027
          </p>
        </Reveal>
        <div>
          {dates.map(([t, d], i) => (
            <Reveal className="date-row" key={t}>
              <span>{String(i + 1).padStart(2, "0")}</span>
              <h3>{t}</h3>
              <b>{d}</b>
              <CalendarDays />
            </Reveal>
          ))}
        </div>
      </section>
      <CTA />
      <section
        className="feature-film photo-reel home-archive"
        aria-label="Highlights from the 2025 conference"
      >
        <div className="reel-frames">
          {homeMedia.map((frame, index) => (
            <figure
              key={frame.src}
              style={{ "--frame": index } as React.CSSProperties}
            >
              <img src={frame.src} alt={frame.alt} />
              <figcaption>{frame.label}</figcaption>
            </figure>
          ))}
        </div>
        <div className="film-shade" />
        <div className="reel-grain" />
        <Reveal className="reel-overlay compact-reel-overlay">
          <div>
            <span>GCGC 2025 · KARACHI</span>
            <h2>Conference in motion</h2>
          </div>
          <Link className="reel-link" to="/archive">
            <span>VIEW THE 2025 ARCHIVE</span>
            <ArrowRight />
          </Link>
        </Reveal>
      </section>
      {selectedTrack !== null && (
        <div
          className="track-dialog"
          role="dialog"
          aria-modal="true"
          aria-label="Conference track details"
        >
          <button
            className="dialog-backdrop"
            onClick={() => setSelectedTrack(null)}
            aria-label="Close track details"
          />
          <motion.article
            initial={{ opacity: 0, y: 30, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
          >
            <button
              className="dialog-close"
              onClick={() => setSelectedTrack(null)}
              aria-label="Close"
            >
              <X />
            </button>
            <span>TRACK / {trackGroups[selectedTrack].number}</span>
            <h2>{trackGroups[selectedTrack].title}</h2>
            <div>
              <small>RESEARCH AREAS</small>
              <ul>
                {trackGroups[selectedTrack].topics.map(([number, title]) => (
                  <li key={number}>
                    <b>{number}</b> {title}
                  </li>
                ))}
              </ul>
            </div>
            <Button to="/call-for-papers">Submission guidance</Button>
          </motion.article>
        </div>
      )}
    </>
  );
}

function CTA() {
  return (
    <section className="cta">
      <span className="eyebrow">GCGC 2027 · LAHORE</span>
      <h2>Advance low-carbon construction</h2>
      <p>
        Share research that can move sustainable materials from evidence into
        practice
      </p>
      <div className="actions">
        <Button to="/call-for-papers">Submission guidelines</Button>
        <Button to="/registration" ghost>
          Register interest
        </Button>
      </div>
    </section>
  );
}

function About() {
  const principles = [
    ["Research integrity", ShieldCheck],
    ["Industrial relevance", Factory],
    ["Climate accountability", Leaf],
    ["Open collaboration", Users],
  ] as const;
  return (
    <>
      <PageHero
        eyebrow="ABOUT GCGC 2027"
        title="An event designed to move research into practice"
        copy="A focused international forum for green construction materials, sustainable production and low-carbon building practice"
      />
      <section className="about-reference section">
        <Reveal>
          <span className="eyebrow dark">OUR PURPOSE</span>
          <h2>Connecting materials research with climate action</h2>
        </Reveal>
        <Reveal className="about-copy">
          <h3>One platform for shared action</h3>
          <p>
            Building materials contribute nearly 11% of global CO₂ emissions.
            GCGC brings industry, academia, and government together on one
            platform to share ideas, collaborate, and mitigate this impact.
          </p>
          <p>
            Across two days, the conference will connect material innovation
            with performance, policy, manufacturing and real-world delivery.
          </p>
        </Reveal>
        <div className="about-image-row">
          <img
            src={img("gcgc-2025/event-03.webp")}
            alt="A construction-material demonstration during the 2025 conference"
          />
          <img
            src={img("gcgc-2025/event-09.webp")}
            alt="The completed low-carbon demonstration structure at NED University"
          />
          <img
            src={img("gcgc-2025/event-16.webp")}
            alt="The demonstration structure prepared for its GCGC 2025 inauguration"
          />
        </div>
      </section>
      <section className="principles-section section">
        <div className="principles-heading">
          <span className="eyebrow dark">WHAT GUIDES THE PROGRAMME</span>
          <h2>Four principles, one focused conference</h2>
        </div>
        <div className="principle-cards">
          {principles.map(([title, Icon]) => (
            <Reveal className="principle-card" key={title}>
              <div>
                <Icon />
              </div>
              <h3>{title}</h3>
              <p>
                A clear standard for rigorous, relevant and application-oriented
                exchange
              </p>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}

function Speakers() {
  return (
    <>
      <PageHero
        eyebrow="VISIONARY MINDS"
        title="Speakers shaping material futures"
        copy="Keynote speakers, plenary guests and industry voices will appear here as they are confirmed"
      />
      <section className="speaker-showcase section">
        <span className="outline-title">SPEAKERS</span>
        <div className="showcase-heading">
          <span className="eyebrow dark">KEYNOTE SPEAKERS</span>
          <h2>Meet the keynote speakers</h2>
        </div>
        <div className="keynote-row">
          {[1, 2, 3, 4].map((n) => (
            <article className="keynote-card" key={n}>
              <div className="portrait">
                <span>
                  TO BE
                  <br />
                  ANNOUNCED
                </span>
              </div>
              <div>
                <b>Keynote speaker</b>
                <small>Institution to be confirmed</small>
              </div>
            </article>
          ))}
        </div>
        <div className="speaker-progress">
          <span />
          <button aria-label="Previous speakers">
            <ArrowLeft />
          </button>
          <button aria-label="Next speakers">
            <ArrowRight />
          </button>
        </div>
        <h2 className="other-heading">Other speakers</h2>
        <div className="other-speakers">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
            <article key={n}>
              <div className="mini-portrait">TBA</div>
              <b>Speaker name</b>
              <small>Role · Institution</small>
            </article>
          ))}
        </div>
        <p className="placeholder-note">
          Preview layout only — all names, roles and photographs await official
          confirmation
        </p>
      </section>
    </>
  );
}

function CallForPapers() {
  const steps = [
    [
      "01",
      "Create or log in to EasyChair",
      "Authors must create an EasyChair account or use an existing account.",
    ],
    [
      "02",
      "Select GCGC 2027",
      "Access the official GCGC 2027 submission portal.",
    ],
    [
      "03",
      "Enter paper information",
      "Provide the title, abstract, keywords, author names, affiliations and corresponding-author details.",
    ],
    [
      "04",
      "Select a conference track",
      "Choose the most relevant track and research area.",
    ],
    [
      "05",
      "Upload the manuscript",
      "Use the prescribed GCGC 2027 paper template.",
    ],
    [
      "06",
      "Peer review",
      "Relevant experts will review each submitted manuscript.",
    ],
    [
      "07",
      "Revision",
      "Submit a revised manuscript and responses to reviewer comments within the stated deadline.",
    ],
    [
      "08",
      "Final submission",
      "Upload the camera-ready manuscript and complete registration requirements.",
    ],
  ];
  const requirements = [
    "One author must be identified as the corresponding author.",
    "Authors are responsible for the originality of their submissions.",
    "Simultaneous submission to another conference or journal is not permitted.",
    "Plagiarism and excessive similarity may result in rejection.",
    "Acceptance will be based on technical quality, originality, relevance and clarity.",
    "At least one author of each accepted paper must register and present the work at GCGC 2027.",
  ];
  return (
    <>
      <PageHero
        eyebrow="CALL FOR PAPERS"
        title="Research with real-world consequence"
        copy="We invite original research advancing low-carbon construction materials, sustainable construction and applied practice"
      />
      <section className="paper-intro section">
        <Reveal className="paper-statement">
          <span className="eyebrow dark">THE INVITATION</span>
          <h2>
            Original thinking
            <br />
            Measurable impact
          </h2>
          <p>
            All manuscripts will be submitted electronically through the GCGC
            2027 EasyChair Submission Portal.
          </p>
        </Reveal>
        <Reveal className="paper-overview-card">
          <span className="paper-card-label">SUBMISSION ACCESS</span>
          <h3>EasyChair portal</h3>
          <p>
            The dedicated GCGC 2027 EasyChair link has not yet been provided.
            Submission access will appear here as soon as it is confirmed.
          </p>
          <span className="button disabled">Portal link to be added</span>
          <small>
            Download the official author files below while portal access is
            being finalized
          </small>
        </Reveal>
      </section>
      <SubmissionDownloads />
      <section className="tracks section alt">
        <span className="eyebrow dark">03 TRACKS · 09 RESEARCH AREAS</span>
        <h2>Research tracks</h2>
        <div className="track-groups">
          {trackGroups.map((group, index) => (
            <details
              className="track-group"
              key={group.number}
              open={index === 0}
            >
              <summary>
                <div>
                  <b>TRACK {group.number}</b>
                  <h3>{group.title}</h3>
                </div>
                <span>
                  View research areas <ArrowRight />
                </span>
              </summary>
              <ol start={index * 3 + 1}>
                {group.topics.map(([number, title]) => (
                  <li key={number}>
                    <b>{number}</b>
                    <span>{title}</span>
                  </li>
                ))}
              </ol>
            </details>
          ))}
        </div>
      </section>
      <section className="submission-cycle section">
        <div className="cycle-heading">
          <span className="eyebrow dark">EASYCHAIR WORKFLOW</span>
          <h2>From manuscript to final submission</h2>
          <p>Follow the eight stages in sequence</p>
        </div>
        <div className="cycle-layout">
          <div className="cycle-core">
            <small>GCGC 2027</small>
            <b>
              Submission
              <br />
              cycle
            </b>
          </div>
          {steps.map(([number, title, copy], index) => (
            <article
              className={`cycle-step cycle-step-${index + 1}`}
              key={number}
            >
              <b>{number}</b>
              <div>
                <h3>{title}</h3>
                <p>{copy}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="requirements-section section">
        <div>
          <span className="eyebrow">BEFORE YOU SUBMIT</span>
          <h2>Submission requirements</h2>
          <a href="mailto:nc4scm@cloud.neduet.edu.pk">
            nc4scm@cloud.neduet.edu.pk <Mail />
          </a>
        </div>
        <ul>
          {requirements.map((item) => (
            <li key={item}>
              <ShieldCheck />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </section>
      <section className="submission-links section">
        <div>
          <small>EASYCHAIR SUBMISSION LINK</small>
          <b>To be added</b>
        </div>
        <div>
          <small>CONFERENCE EMAIL</small>
          <a href="mailto:nc4scm@cloud.neduet.edu.pk">
            nc4scm@cloud.neduet.edu.pk
          </a>
        </div>
      </section>
      <CTA />
    </>
  );
}

function Programme() {
  const [day, setDay] = useState(0);
  const sample = [
    "Registration & welcome",
    "Opening session",
    "Keynote address",
    "Technical sessions",
    "Industry dialogue",
  ];
  return (
    <>
      <PageHero
        eyebrow="CONFERENCE PROGRAMME"
        title="Two days of ideas, evidence and exchange"
        copy="The layout below previews the programme format. Final sessions and timings are still to be confirmed."
      />
      <section className="schedule-reference section">
        <span className="outline-title">PROGRAMME</span>
        <div className="showcase-heading">
          <span className="eyebrow dark">SCHEDULE</span>
          <h2>Conference programme</h2>
        </div>
        <div className="day-tabs">
          {["First Day · 27 April", "Second Day · 28 April"].map(
            (label, index) => (
              <button
                className={day === index ? "active" : ""}
                onClick={() => setDay(index)}
                key={label}
              >
                <small>{index === 0 ? "Tuesday" : "Wednesday"}</small>
                <b>{label}</b>
              </button>
            ),
          )}
        </div>
        <div className="schedule-list">
          {sample.map((title, index) => (
            <Reveal className="schedule-row" key={`${day}-${title}`}>
              <div>
                <b>{String(9 + index).padStart(2, "0")}:00</b>
                <span>
                  <MapPin /> Venue TBC
                </span>
              </div>
              <article>
                <h3>{title}</h3>
                <p>
                  Official session description and confirmed speakers will be
                  added when provided.
                </p>
                {index === 2 && <small>SPEAKER: TO BE ANNOUNCED</small>}
              </article>
            </Reveal>
          ))}
        </div>
        <p className="placeholder-note">
          This is a visual programme preview, not the confirmed agenda.
        </p>
      </section>
    </>
  );
}
function Registration() {
  return (
    <>
      <PageHero
        eyebrow="ATTEND GCGC 2027"
        title="Register your interest"
        copy="Registration categories and approved fees will be published by the conference team."
      />
      <section className="section price-grid">
        {[
          "Early bird",
          "Standard delegate",
          "Student",
          "International delegate",
        ].map((x, i) => (
          <Reveal className={i === 0 ? "price featured" : "price"} key={x}>
            <span>{i === 0 ? "REGISTRATION PREVIEW" : "REGISTRATION"}</span>
            <h3>{x}</h3>
            <b>Fee TBC</b>
            <p>Access package and eligibility details to be confirmed.</p>
            <ul>
              <li>Conference sessions</li>
              <li>Digital programme</li>
              <li>Networking access</li>
              <li>Certificate policy TBC</li>
            </ul>
            <button className="button disabled">Opening soon</button>
          </Reveal>
        ))}
      </section>
      <section className="guide section">
        <h2>Registration policies</h2>
        {[
          "Payment method",
          "Cancellation policy",
          "Author registration rule",
          "International delegate guidance",
        ].map((x) => (
          <div key={x}>
            <b>{x}</b>
            <span>Official information required</span>
          </div>
        ))}
      </section>
    </>
  );
}
function Committees() {
  const groups = [...people, "International advisory board"];
  return (
    <>
      <PageHero
        eyebrow="PEOPLE BEHIND THE CONFERENCE"
        title="Committees and governance"
        copy="Confirmed committee membership will be published after approval by the conference organizers"
      />
      <section className="committee-section section">
        <div className="committee-heading">
          <div>
            <span className="eyebrow dark">GOVERNANCE STRUCTURE</span>
            <h2>Conference committees</h2>
          </div>
          <p>
            The committee categories are prepared. Names, roles and affiliations
            will be added only after official confirmation.
          </p>
        </div>
        <div className="committee-grid">
          {groups.map((role) => (
            <Reveal className="committee-card" key={role}>
              <div className="committee-card-top">
                <Users aria-hidden="true" />
              </div>
              <div>
                <small>COMMITTEE</small>
                <h3>{role}</h3>
              </div>
              <p>Membership to be announced</p>
            </Reveal>
          ))}
        </div>
        <div className="committee-empty">
          <Users aria-hidden="true" />
          <div>
            <span className="eyebrow">MEMBERSHIP UPDATE</span>
            <h3>Official names are being finalized</h3>
            <p>
              This page will be updated when the conference team provides the
              approved committee list.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
function Partners() {
  const options = [
    [
      "Research partner",
      "Connect academic expertise with applied industry challenges",
      FlaskConical,
    ],
    [
      "Industry partner",
      "Bring materials, manufacturing and delivery experience into the programme",
      Factory,
    ],
    [
      "Supporting partner",
      "Help widen access, participation and professional exchange",
      Handshake,
    ],
  ] as const;
  return (
    <>
      <PageHero
        eyebrow="PARTNERS"
        title="Partnership that accelerates progress"
        copy="Organizations can contribute expertise, industry perspective and support to GCGC 2027"
      />
      <section className="partners-reference section">
        <span className="outline-title">PARTNERS</span>
        <div className="showcase-heading">
          <span className="eyebrow dark">WORK WITH GCGC 2027</span>
          <h2>Choose how to contribute</h2>
        </div>
        <div className="partner-option-grid">
          {options.map(([title, copy, Icon]) => (
            <article className="partner-option" key={title}>
              <Icon />
              <h3>{title}</h3>
              <p>{copy}</p>
              <Button to="/contact" ghost>
                Discuss partnership
              </Button>
            </article>
          ))}
        </div>
        <div className="confirmed-partners">
          <div>
            <span className="eyebrow dark">CONFIRMED ORGANIZATIONS</span>
            <h3>Official logos will appear here</h3>
          </div>
          <p>
            No organizations are shown until their participation and brand
            assets are confirmed
          </p>
        </div>
      </section>
    </>
  );
}
function Archive() {
  const [edition, setEdition] = useState("2025");
  const [selectedMedia, setSelectedMedia] = useState<number | null>(null);
  const media: MediaItem[] = [
    {
      src: img("gcgc-2025/event-02.webp"),
      alt: "An international guest addressing GCGC 2025 remotely",
      label: "International knowledge exchange · 2025",
    },
    {
      src: img("gcgc-2025/event-04.webp"),
      alt: "Delegates applauding during an outdoor GCGC 2025 activity",
      label: "A shared milestone · 2025",
    },
    {
      src: img("gcgc-2025/event-05.webp"),
      alt: "A guest speaker presenting during GCGC 2025",
      label: "Voices shaping practice · 2025",
    },
    {
      src: img("gcgc-2025/event-06.webp"),
      alt: "Guests and participants gathered during GCGC 2025",
      label: "Conference connections · 2025",
    },
    {
      src: img("gcgc-2025/event-08.webp"),
      alt: "A collage documenting the low-carbon demonstration structure",
      label: "Research moving into practice · 2025",
    },
    {
      src: img("gcgc-2025/event-10.webp"),
      alt: "An interview recorded beside the demonstration project",
      label: "Field perspectives · 2025",
    },
    {
      src: img("gcgc-2025/event-11.webp"),
      alt: "Recognition presented to a GCGC 2025 contributor",
      label: "Recognising contribution · 2025",
    },
    {
      src: img("gcgc-2025/event-12.webp"),
      alt: "A conference speaker addressing the auditorium",
      label: "Ideas from the stage · 2025",
    },
    {
      src: img("gcgc-2025/event-13.webp"),
      alt: "Conference representatives gathered after a recognition ceremony",
      label: "Professional exchange · 2025",
    },
    {
      src: img("gcgc-2025/event-15.webp"),
      alt: "Guests examining low-carbon construction material samples",
      label: "Materials in practice · 2025",
    },
  ];
  return (
    <>
      <PageHero
        eyebrow="MEDIA + CONFERENCE IN MOTION"
        title="Ideas carried forward"
        copy="Explore the people, dialogue and applied work that shaped the 2025 conference"
      />
      <section className="archive-editions">
        <div className="edition-tabs" role="tablist">
          {["2027", "2025", "Future archive"].map((x) => (
            <button
              key={x}
              className={edition === x ? "active" : ""}
              onClick={() => setEdition(x)}
              role="tab"
            >
              {x}
            </button>
          ))}
        </div>
        {edition === "2025" ? (
          <div className="edition-layout">
            <Reveal className="edition-story">
              <span className="eyebrow dark">GCGC 2025 · KARACHI</span>
              <h2>Conference in motion</h2>
              <p>
                Held on 5–6 February 2025, the Global Conference on Green
                Construction Materials and Practices brought academia together
                with the cement and concrete industry for scientific dialogue,
                practical demonstration and collaboration.
              </p>
              <a
                className="text-link"
                href="https://lc3.ch/2025/02/25/global-conference-on-green-construction-materials-practices-in-pakistan/"
                target="_blank"
                rel="noreferrer"
              >
                Read the LC3 conference report <ExternalLink />
              </a>
              <div className="edition-stats">
                <div>
                  <CalendarCheck />
                  <span>WHEN</span>
                  <b>5–6 February 2025</b>
                </div>
                <div>
                  <MapPin />
                  <span>WHERE</span>
                  <b>Karachi, Pakistan</b>
                </div>
                <div>
                  <Users />
                  <span>FORMAT</span>
                  <b>Academia + industry</b>
                </div>
              </div>
            </Reveal>
            <Reveal className="edition-aside">
              <span>CONFERENCE FOCUS</span>
              <h3>Green construction materials and practices</h3>
              <ul>
                <li>Sustainable cement and concrete</li>
                <li>Industry–academia collaboration</li>
                <li>Eco-friendly construction practice</li>
              </ul>
            </Reveal>
            <div className="edition-gallery archive-grid">
              <button
                className="gallery-lead"
                onClick={() => setSelectedMedia(0)}
                aria-label="Enlarge archive image 1"
              >
                <img src={media[0].src} alt={media[0].alt} />
                <span>01 / {String(media.length).padStart(2, "0")}</span>
                <i>
                  <Maximize2 /> VIEW
                </i>
              </button>
              <div className="gallery-thumbs">
                {media.slice(1).map((item, index) => (
                  <button
                    key={item.src}
                    onClick={() => setSelectedMedia(index + 1)}
                    aria-label={`Enlarge ${item.alt}`}
                  >
                    <img src={item.src} alt={item.alt} />
                    <span>{String(index + 2).padStart(2, "0")}</span>
                    <i>
                      <Maximize2 />
                    </i>
                  </button>
                ))}
              </div>
            </div>
            <aside className="archive-highlights">
              <Images />
              <span>2025 HIGHLIGHTS</span>
              <h3>Ideas, demonstrations and dialogue</h3>
              <div className="highlight-tags">
                <span>Technical sessions</span>
                <span>Material demonstrations</span>
                <span>Industry exchange</span>
              </div>
            </aside>
          </div>
        ) : (
          <div className="archive-empty">
            <Leaf />
            <span>{edition}</span>
            <h2>
              {edition === "2027"
                ? "The current edition is taking shape"
                : "More editions will live here"}
            </h2>
            <p>
              Programme, speakers, gallery and proceedings will be published
              after official confirmation.
            </p>
          </div>
        )}
      </section>
      {selectedMedia !== null && (
        <MediaLightbox
          items={media}
          index={selectedMedia}
          onIndex={setSelectedMedia}
          onClose={() => setSelectedMedia(null)}
        />
      )}
    </>
  );
}
function Contact() {
  return (
    <>
      <PageHero
        eyebrow="CONTACT GCGC 2027"
        title="Start a conversation"
        copy="Questions about papers, registration, partnership or participation? Use the relevant contact route below."
      />
      <section className="contact section">
        <div className="contact-details">
          <span className="eyebrow">CONTACT INFORMATION</span>
          <h2>
            GCGC 2027
            <br />
            Conference Contact
          </h2>
          <p className="contact-lead">
            For papers, registration, partnerships and general conference
            enquiries
          </p>
          <div className="contact-fact">
            <CalendarDays />
            <div>
              <small>CONFERENCE DATES</small>
              <b>27–28 April 2027</b>
            </div>
          </div>
          <div className="contact-fact">
            <MapPin />
            <div>
              <small>EXPECTED VENUE</small>
              <b>UET Lahore</b>
              <span>Complete address to be confirmed</span>
            </div>
          </div>
          <a className="contact-fact" href="mailto:nc4scm@cloud.neduet.edu.pk">
            <Mail />
            <div>
              <small>OFFICIAL EMAIL</small>
              <b>nc4scm@cloud.neduet.edu.pk</b>
            </div>
          </a>
        </div>
        <form
          action="https://formsubmit.co/nc4scm@cloud.neduet.edu.pk"
          method="POST"
        >
          <span className="form-label">SEND AN ENQUIRY</span>
          <h3>How can we help?</h3>
          <input
            type="hidden"
            name="_subject"
            value="New GCGC 2027 website enquiry"
          />
          <input type="hidden" name="_template" value="table" />
          <input type="hidden" name="_captcha" value="false" />
          <input
            className="form-honeypot"
            type="text"
            name="_honey"
            tabIndex={-1}
            autoComplete="off"
          />
          <label>
            Name
            <input name="name" placeholder="Your full name" required />
          </label>
          <label>
            Email
            <input
              name="email"
              type="email"
              placeholder="you@example.com"
              required
            />
          </label>
          <label>
            Subject
            <select name="subject">
              <option>General enquiry</option>
              <option>Paper submission</option>
              <option>Registration</option>
              <option>Partnership</option>
            </select>
          </label>
          <label>
            Message
            <textarea
              name="message"
              rows={5}
              placeholder="Write your message"
              required
            />
          </label>
          <button className="button" type="submit">
            <Send size={17} /> Send enquiry
          </button>
        </form>
      </section>
    </>
  );
}

function App() {
  const loc = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [loc.pathname]);

  return (
    <>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/speakers" element={<Speakers />} />
          <Route path="/call-for-papers" element={<CallForPapers />} />
          <Route path="/programme" element={<Programme />} />
          <Route path="/registration" element={<Registration />} />
          <Route path="/committees" element={<Committees />} />
          <Route path="/partners" element={<Partners />} />
          <Route path="/archive" element={<Archive />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      <Footer />
      <SpeedInsights />
    </>
  );
}

export default App;
